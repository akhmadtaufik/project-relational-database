--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.3
-- Dumped by pg_dump version 15.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "used-car-db";
--
-- Name: used-car-db; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "used-car-db" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_Indonesia.1252';


ALTER DATABASE "used-car-db" OWNER TO postgres;

\connect -reuse-previous=on "dbname='used-car-db'"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: advertisements; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.advertisements (
    ad_id integer NOT NULL,
    user_id integer NOT NULL,
    title character varying(100) NOT NULL,
    price numeric NOT NULL,
    description text NOT NULL,
    car_id integer NOT NULL,
    date_posted timestamp without time zone NOT NULL
);


ALTER TABLE public.advertisements OWNER TO postgres;

--
-- Name: bids; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bids (
    bid_id integer NOT NULL,
    ad_id integer NOT NULL,
    user_id integer NOT NULL,
    bid_price numeric NOT NULL,
    bid_status character varying(10) NOT NULL,
    datetime_bid timestamp without time zone NOT NULL,
    CONSTRAINT bids_bid_price_check CHECK ((bid_price > (0)::numeric)),
    CONSTRAINT bids_bid_status_check CHECK (((bid_status)::text = ANY (ARRAY[('approved'::character varying)::text, ('rejected'::character varying)::text, ('sent'::character varying)::text])))
);


ALTER TABLE public.bids OWNER TO postgres;

--
-- Name: bids_bid_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.bids_bid_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.bids_bid_id_seq OWNER TO postgres;

--
-- Name: bids_bid_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.bids_bid_id_seq OWNED BY public.bids.bid_id;


--
-- Name: body_types; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.body_types (
    body_type_id character varying(6) NOT NULL,
    body_type_name character varying(25) NOT NULL
);


ALTER TABLE public.body_types OWNER TO postgres;

--
-- Name: cars; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cars (
    car_id integer NOT NULL,
    manufacture_id character varying(4) NOT NULL,
    model_id character varying(6) NOT NULL,
    body_type_id character varying(6) NOT NULL,
    year_manufactured integer NOT NULL,
    engine_capacity numeric NOT NULL,
    passenger_capacity integer NOT NULL,
    transmission_type character varying(10) NOT NULL,
    fuel_type character varying(10) NOT NULL,
    drive_system character varying(5) NOT NULL,
    odometer integer,
    additional_details text,
    CONSTRAINT cars_drive_system_check CHECK (((drive_system)::text = ANY (ARRAY[('FWD'::character varying)::text, ('RWD'::character varying)::text, ('AWD'::character varying)::text]))),
    CONSTRAINT cars_engine_capacity_check CHECK (((engine_capacity >= (0)::numeric) AND (engine_capacity < (10)::numeric))),
    CONSTRAINT cars_fuel_type_check CHECK (((fuel_type)::text = ANY (ARRAY[('gasoline'::character varying)::text, ('diesel'::character varying)::text, ('hybrid'::character varying)::text, ('electric'::character varying)::text]))),
    CONSTRAINT cars_odometer_check CHECK ((odometer > 0)),
    CONSTRAINT cars_passenger_capacity_check CHECK (((passenger_capacity > 0) AND (passenger_capacity <= 12))),
    CONSTRAINT cars_transmission_type_check CHECK (((transmission_type)::text = ANY (ARRAY[('manual'::character varying)::text, ('automatic'::character varying)::text]))),
    CONSTRAINT cars_year_manufactured_check CHECK (((year_manufactured > 2000) AND ((year_manufactured)::numeric <= EXTRACT(year FROM CURRENT_DATE))))
);


ALTER TABLE public.cars OWNER TO postgres;

--
-- Name: locations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.locations (
    location_id integer NOT NULL,
    city_name character varying(25) NOT NULL,
    location point
);


ALTER TABLE public.locations OWNER TO postgres;

--
-- Name: manufactures; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.manufactures (
    manufacture_id character varying(4) NOT NULL,
    manufacture_name character varying(25) NOT NULL
);


ALTER TABLE public.manufactures OWNER TO postgres;

--
-- Name: models; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.models (
    model_id character varying(6) NOT NULL,
    manufacture_id character varying(4) NOT NULL,
    model_name character varying(100) NOT NULL
);


ALTER TABLE public.models OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    user_id integer NOT NULL,
    first_name character varying(25) NOT NULL,
    last_name character varying(25) NOT NULL,
    email character varying(75) NOT NULL,
    contact character varying(25) NOT NULL,
    location_id integer NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: bids bid_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bids ALTER COLUMN bid_id SET DEFAULT nextval('public.bids_bid_id_seq'::regclass);


--
-- Data for Name: advertisements; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.advertisements (ad_id, user_id, title, price, description, car_id, date_posted) FROM stdin;
\.
COPY public.advertisements (ad_id, user_id, title, price, description, car_id, date_posted) FROM '$$PATH$$/3399.dat';

--
-- Data for Name: bids; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bids (bid_id, ad_id, user_id, bid_price, bid_status, datetime_bid) FROM stdin;
\.
COPY public.bids (bid_id, ad_id, user_id, bid_price, bid_status, datetime_bid) FROM '$$PATH$$/3401.dat';

--
-- Data for Name: body_types; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.body_types (body_type_id, body_type_name) FROM stdin;
\.
COPY public.body_types (body_type_id, body_type_name) FROM '$$PATH$$/3393.dat';

--
-- Data for Name: cars; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cars (car_id, manufacture_id, model_id, body_type_id, year_manufactured, engine_capacity, passenger_capacity, transmission_type, fuel_type, drive_system, odometer, additional_details) FROM stdin;
\.
COPY public.cars (car_id, manufacture_id, model_id, body_type_id, year_manufactured, engine_capacity, passenger_capacity, transmission_type, fuel_type, drive_system, odometer, additional_details) FROM '$$PATH$$/3396.dat';

--
-- Data for Name: locations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.locations (location_id, city_name, location) FROM stdin;
\.
COPY public.locations (location_id, city_name, location) FROM '$$PATH$$/3397.dat';

--
-- Data for Name: manufactures; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.manufactures (manufacture_id, manufacture_name) FROM stdin;
\.
COPY public.manufactures (manufacture_id, manufacture_name) FROM '$$PATH$$/3394.dat';

--
-- Data for Name: models; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.models (model_id, manufacture_id, model_name) FROM stdin;
\.
COPY public.models (model_id, manufacture_id, model_name) FROM '$$PATH$$/3395.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (user_id, first_name, last_name, email, contact, location_id) FROM stdin;
\.
COPY public.users (user_id, first_name, last_name, email, contact, location_id) FROM '$$PATH$$/3398.dat';

--
-- Name: bids_bid_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.bids_bid_id_seq', 1002, true);


--
-- Name: advertisements advertisements_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.advertisements
    ADD CONSTRAINT advertisements_pkey PRIMARY KEY (ad_id);


--
-- Name: bids bids_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bids
    ADD CONSTRAINT bids_pkey PRIMARY KEY (bid_id);


--
-- Name: body_types body_types_body_type_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.body_types
    ADD CONSTRAINT body_types_body_type_name_key UNIQUE (body_type_name);


--
-- Name: body_types body_types_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.body_types
    ADD CONSTRAINT body_types_pkey PRIMARY KEY (body_type_id);


--
-- Name: cars cars_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cars
    ADD CONSTRAINT cars_pkey PRIMARY KEY (car_id);


--
-- Name: locations locations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.locations
    ADD CONSTRAINT locations_pkey PRIMARY KEY (location_id);


--
-- Name: manufactures manufactures_manufacture_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.manufactures
    ADD CONSTRAINT manufactures_manufacture_name_key UNIQUE (manufacture_name);


--
-- Name: manufactures manufactures_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.manufactures
    ADD CONSTRAINT manufactures_pkey PRIMARY KEY (manufacture_id);


--
-- Name: models models_model_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.models
    ADD CONSTRAINT models_model_name_key UNIQUE (model_name);


--
-- Name: models models_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.models
    ADD CONSTRAINT models_pkey PRIMARY KEY (model_id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_first_name_last_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_first_name_last_name_key UNIQUE (first_name, last_name);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (user_id);


--
-- Name: idx_ads_car; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ads_car ON public.advertisements USING btree (car_id);


--
-- Name: idx_ads_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ads_user ON public.advertisements USING btree (user_id);


--
-- Name: idx_cars_body_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_cars_body_type ON public.cars USING btree (body_type_id);


--
-- Name: idx_cars_manufacture_model; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_cars_manufacture_model ON public.cars USING btree (manufacture_id, model_id);


--
-- Name: idx_locations_location; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_locations_location ON public.locations USING gist (location);


--
-- Name: advertisements fk_ads_car; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.advertisements
    ADD CONSTRAINT fk_ads_car FOREIGN KEY (car_id) REFERENCES public.cars(car_id);


--
-- Name: advertisements fk_ads_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.advertisements
    ADD CONSTRAINT fk_ads_user FOREIGN KEY (user_id) REFERENCES public.users(user_id) ON DELETE CASCADE;


--
-- Name: bids fk_bid_ads; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bids
    ADD CONSTRAINT fk_bid_ads FOREIGN KEY (ad_id) REFERENCES public.advertisements(ad_id);


--
-- Name: bids fk_bid_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bids
    ADD CONSTRAINT fk_bid_user FOREIGN KEY (user_id) REFERENCES public.users(user_id) ON DELETE CASCADE;


--
-- Name: cars fk_car_body_type; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cars
    ADD CONSTRAINT fk_car_body_type FOREIGN KEY (body_type_id) REFERENCES public.body_types(body_type_id);


--
-- Name: cars fk_car_manufacture; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cars
    ADD CONSTRAINT fk_car_manufacture FOREIGN KEY (manufacture_id) REFERENCES public.manufactures(manufacture_id);


--
-- Name: cars fk_car_model; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cars
    ADD CONSTRAINT fk_car_model FOREIGN KEY (model_id) REFERENCES public.models(model_id);


--
-- Name: models fk_car_model_manufacture; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.models
    ADD CONSTRAINT fk_car_model_manufacture FOREIGN KEY (manufacture_id) REFERENCES public.manufactures(manufacture_id);


--
-- Name: users fk_user_location; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT fk_user_location FOREIGN KEY (location_id) REFERENCES public.locations(location_id);


--
-- PostgreSQL database dump complete
--

